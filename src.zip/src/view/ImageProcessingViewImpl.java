package view;

import java.io.IOException;

/**
 * Implementation of ImageProcessingView that implements inherited methods.
 */
public class ImageProcessingViewImpl implements ImageProcessingView {

  private final Appendable appendable;

  /**
   * Creates an ImageProcessingViewImpl.
   * @param appendable the appendable.
   */
  public ImageProcessingViewImpl(Appendable appendable) {
    if (appendable == null) {
      throw new IllegalArgumentException("appendable is null");
    }

    this.appendable = appendable;
  }

  /**
   * Creates a default ImageProcessingViewImpl.
   */
  // TODO: do we need this?
  public ImageProcessingViewImpl() {
    this(System.out);
  }

  /**
   * Renders the message.
   * @param message the message to be rendered.
   * @throws IOException if the message is unable to be rendered.
   */
  @Override
  public void renderMessage(String message) throws IOException {
    this.appendable.append(message);
  }
}
